from django.apps import AppConfig


class Abc6Config(AppConfig):
    name = 'abc6'
