from django.shortcuts import render
from django import views
from rest_framework import viewsets
from .models import parameters
from .serializers import paraSerializer
from rest_framework.response import Response
import random
import django
import datetime
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.dates import DateFormatter
import speech_recognition as sr
import urllib.parse,urllib.request
import json
# Create your views here.

class paraViewset(viewsets.ModelViewSet):

    queryset = parameters.objects.all()
    serializer_class = paraSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        AudioFile = (request.data['user'])
        r = sr.Recognizer()
        with sr.AudioFile(AudioFile) as source:
            audio = r.record(source)
        text = r.recognize_google(audio)
        data = urllib.parse.urlencode({"text": text})
        data = data.encode('utf-8')
        u = urllib.request.urlopen("http://text-processing.com/api/sentiment/", data)
        the_page = u.read()
        content=u.info().get_content_charset('utf8')
        data = json.loads(the_page.decode(content))
        data.update({'text': text})
        self.perform_create(serializer)
        return Response(data)

    def perform_create(self, serializer):
        serializer.save()
