from rest_framework import serializers
from .models import parameters

class paraSerializer(serializers.ModelSerializer):
    class Meta:
        model=parameters