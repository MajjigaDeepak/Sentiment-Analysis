import speech_recognition as sr
import urllib.parse,urllib.request
import json


AudioFile=("C:\\Users\\380173\\Desktop\\a.wav")
r=sr.Recognizer()
with sr.AudioFile(AudioFile) as source:
    audio=r.record(source)
try:
    print(r.recognize_google(audio))
    text=r.recognize_google(audio)
except sr.UnknownValueError:
    print("Didn't understand")
except sr.RequestError as e:
    print(format(e))

text=r.recognize_google(audio)
data = urllib.parse.urlencode({"text": text})
data=data.encode('utf-8')
u = urllib.request.urlopen("http://text-processing.com/api/sentiment/", data)
u1=u.read()
t=u.info().get_content_charset('utf8')
data = json.loads(u1.decode(t))
print(type(text))
print(data)



